# DSS TV V5 — Admin dashboard

Upload **the contents** of this package to the root of your existing GitHub repository. Preserve the `admin/` directory. GitHub triggers Netlify automatically.

Visit `https://dsstv.netlify.app/admin/`. The admin editor uses GitHub's API directly and does **not** provide a secure server-side login. It requires a fine-grained personal access token with **Contents: Read and write** permission limited to your DSS TV repository. Generate it in GitHub Settings → Developer settings → Personal access tokens → Fine-grained tokens. Set a short expiration. Do not paste the token into website source, screenshots, or messages. The editor keeps it in tab memory only.

Enter your GitHub username and repo name, then token; click Load catalog. Make edits, save locally, and Publish catalog. Uploading a poster commits the image separately; you must then publish the catalog to reference it. Drafts have `published:false` and are hidden from the public site. Published items can be marked trending. The current public site shows all published review items in the Reviews rail and the corresponding year rail.

Security limitations: this is a client-side editor and its page is publicly accessible. The token protects write access; anyone who knows a valid token can edit the repository. Use a short-lived repository-scoped token, avoid browser extensions you do not trust, and never commit secrets. For multi-user production use, replace this with an authenticated CMS/OAuth backend.

Note: Netlify's deployment file browser and your existing repository showed the four main asset files in the repository root. This package uses `assets/...` paths consistent with the V4 ZIP. If your GitHub repository has images at the root instead of `assets/`, upload the folder structure from this package and commit all files together.
